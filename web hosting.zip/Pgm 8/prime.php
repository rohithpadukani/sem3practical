<html>
<head>
    <title>Prime Numbers</title>
</head>
<body>
    <form action="" method="get">
        <h1>Prime Number</h1>
    <input type="text" name="no1" id="no1" placeholder="Enter First Number"/>
    <input type="text" name="no2" id="no2" placeholder="Enter Second Number"/>
    <input type="submit" value="Submit"><br><br><br>
    </form>
</body>
</html>
<?php
    if($_GET){
        $flag=false;
        $n1= $_GET["no1"];
        $n2= $_GET["no2"];
        echo "The Prime numbers between $n1 and $n2 is : \n";
        for($i=$n1;$i<=$n2;$i++){
            if($i==1 || $i==2){
                echo $i."\n";
            }
            for($j=2;$j<$i;$j++){
                if($i % $j==0){
                    $flag =false;
                    break;
                }
                $flag = true;
            }
            if($flag){
                echo $i."\n";
            }
        }
    }

?>