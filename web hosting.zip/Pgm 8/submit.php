<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get values from form input
    $n1 = intval($_POST['n1']);
    $n2 = intval($_POST['n2']);
    
    // Function to check if a number is prime
    function is_prime($num) {
        if ($num < 2) {
            return false;
        }
        for ($i = 2; $i <= sqrt($num); $i++) {
            if ($num % $i == 0) {
                return false;
            }
        }
        return true;
    }
    
    // Output HTML structure and display prime numbers
    echo "<html><body bgcolor='skyblue'>";
    echo "<h1><center>Prime Numbers Between $n1 and $n2</center></h1>";
    echo "<h3>Prime numbers between $n1 and $n2:</h3>";
    
    // Loop through numbers between n1 and n2, and print the primes
    $foundPrime = false;
    for ($i = $n1; $i <= $n2; $i++) {
        if (is_prime($i)) {
            echo $i . " ";
            $foundPrime = true;
        }
    }
    
    if (!$foundPrime) {
        echo "No prime numbers found in this range.";
    }

    echo "<br><br><a href='index.html'>Go Back</a>";
    echo "</body></html>";
}
?>
